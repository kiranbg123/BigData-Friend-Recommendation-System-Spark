/*
 * @authour:kxb140230
 * 
 */
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf


import scala.collection.mutable.ArrayBuffer

object FriendRecommender { 

  val IS_FRIEND = -1
 def mapProcess(args: String, targetUIDs: String): Array[(String, (String, Int))] =
  {
    // For exapmle: input "3  8,6,4" -- output tuple (8,(6,1)) (8,(4,1)) etc
    
    //testing...
    //println("reaching code inside mapprocess")
    var mutualFriend = new ArrayBuffer[(String, (String, Int))]()

    val friendList = args.split("\\t")
    // If user has no friend, just return the  array
    if (friendList.length < 2)
    {
      return mutualFriend.toArray 
    }

    val currentUser = friendList(0)
    val friends = friendList(1).split(",")

    var targetUsers = Set[String]()
    targetUIDs.split(",").foreach(uid => targetUsers += uid)


    // If target user is current user, set direct friend
    if (targetUsers.contains(currentUser))
    {
      for (i <- 0 until friends.length)
      {
        mutualFriend += ((currentUser, (friends(i), IS_FRIEND)))
      }
    }

    // check whether target users are in the friend list
    var currentTargetUser = Set[String]()
    for (i <- 0 until friends.length)
    {
      if (targetUsers.contains(friends(i)))
      {
        currentTargetUser += friends(i)
      }
    }
    //friend list does not have target user, then return the array
    if (currentTargetUser.isEmpty)
    {
      return mutualFriend.toArray
    }

    // target user is in friend list, emit target user and his candidate friend, mutual friend is current user
    currentTargetUser.foreach(lpTargetUID =>
    {
      for(j <- 0 until friends.length)
      {
        if (!lpTargetUID.equals(friends(j)))
        {
          val item = (lpTargetUID, (friends(j), 1))
          mutualFriend += item
        }
      }
    })

    mutualFriend.toArray
  }

  def reduceProcess(args:(String, Iterable[(String, Int)])): String = {
    val key = args._1
    var users = Map[String, Int]()

    args._2.foreach(userFriend =>
    {
      val user = userFriend._1
      val mutualFriend = userFriend._2

      if (users.contains(user))
      {
        val count = users(user)
        if (count == -1)
        {
          // If the user is direct friend, do nothing.
        }
        else if (mutualFriend.equals(IS_FRIEND))
        {
          // reset direct friend
          users += (user -> -1)
        }
        else
        {
          users += (user -> (count + 1))
        }
      }
      else
      {
        if (mutualFriend.equals(IS_FRIEND))
        {
          users += (user -> -1)
        }
        else
        {
          users += (user -> 1)
        }
      }
    })

    // sort the candidates by the count of mutual friends with target user (no need)
    // output top 10 recommended friends (no need)

    val friendBuilder = new StringBuilder()
    users.foreach(entry =>
    {
      if (entry._2 != -1) {
        friendBuilder.append(",")
        friendBuilder.append(entry._1)
      }
    })

    if (friendBuilder.nonEmpty)
    {
      friendBuilder.deleteCharAt(0)
    }

    friendBuilder.insert(0, key + "\t")
    friendBuilder.toString()
  }

  def main(args: Array[String]) {
    val conf = new SparkConf().setAppName("Friend Recommendation System")
    conf.set("spark.hadoop.validateOutputSpecs", "false")
    val sc = new SparkContext(conf)
    if(args.length <2)
    {
      println("You should provide input path and output path")
      System.exit(-1)
    }
    val inputPath = args(0)
    val outputPath = args(1)

//Set the target Users to the ones mentioned in the homework
    val targetUsers = sc.broadcast("924,8941,8942,9019,9020,9021,9022,9990,9992,9993")

    val logData = sc.textFile(inputPath)


    val mapResult = logData.flatMap(line => mapProcess(line, targetUsers.value))
    val shuffleResult = mapResult.groupByKey()
    val reduceResult = shuffleResult.map(reduceProcess)


    // Save the file in the directory mentioned
    reduceResult.saveAsTextFile(outputPath)
  }
}