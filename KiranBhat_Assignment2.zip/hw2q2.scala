

import org.apache.spark.{SparkContext, SparkConf}

object MutualFriend {

  def reduceProcess(args:(String, Iterable[String])): String = {
    var friendSet = Set[String]()
    val friendBuilder = new StringBuilder()
    val loTargetPair = args._1

    args._2.foreach(line =>
      {
        val uidAndFriend = line.split("\\t")
        if (uidAndFriend.length > 1)
          {
            val friendList = uidAndFriend(1).split(",")
            friendList.foreach(friend =>
              if (friendSet.contains(friend))
              {
                friendBuilder.append(",")
                friendBuilder.append(friend)
              }
              else
              {
                friendSet += friend
              })
          }
      })

    if(friendBuilder.nonEmpty)
      {
        friendBuilder.deleteCharAt(0)
      }

    friendBuilder.insert(0, loTargetPair + "\t")
    friendBuilder.toString()
  }


  def main(args: Array[String]) {
    val conf = new SparkConf().setAppName("Mutual Friends")
    conf.set("spark.hadoop.validateOutputSpecs", "false")
    val sc = new SparkContext(conf)
    var userIds = Set[String]()
    
    if(args.length<2)
    {
      println("You should provide atlease 2 arguments")
      System.exit(-1)
    }
    else if(args.length >2)
      {
        args(2).split(",").foreach(uid => userIds += uid)
       val  inputPath = args(0)
       val  outputPath = args(1)
  

    val ids = sc.broadcast(userIds)

    val logData = sc.textFile(inputPath)
//Commenting out to see the testing result
     val mapResult = logData.filter(line => ids.value.contains(line.split("\\t")(0)))

    val reduceResult = mapResult.groupBy(line => args(2)).map(reduceProcess)

    // need remove dir before output
    reduceResult.saveAsTextFile(outputPath)
      }
  }
}