

import org.apache.spark.{SparkContext, SparkConf}

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks._

object AverageAgeTop {

  //The following variables are used to calculate the age of the user
  val CURRENT_YEAR = "2016"
  val CURRENT_MONTH = "2"

  // Join two tables by key of each friend in list
  def JoinFriendMapper(value: String): Array[(String, String)] = {
    var record = new ArrayBuffer[(String, String)]()
    val singleRecord = value.split("\\t")
    if (singleRecord.length < 2)
    {
      return record.toArray
    }

    val currentUser = singleRecord(0)
    val friend = singleRecord(1).split(",")
    friend.foreach(friend =>
    {
      record += ((friend, currentUser))
    })

    record.toArray
  }

  def JoinAgeMapper(value:String): (String, Double) = {

    val details = value.split(",")

    val currentUser = details(0)
    val dob = details(9)
    //calculate the age based on dob
    val age = Integer.valueOf(CURRENT_YEAR) - Integer.valueOf(dob.split("/")(2))
    + (Integer.valueOf(CURRENT_MONTH) - Integer.valueOf(dob.split("/")(0))) * 1.0 / 12

    (currentUser, age)
  }

  def JoinFriendAgeReducer(args:(String, (Iterable[String], Iterable[Double]))): Array[(String, Double)] = {
    var record = new ArrayBuffer[(String, Double)]()

    val loAge = args._2._2.head

    //Following to test and debug
/*  friends.foreach(value =>
    {
      record += ((value, loAge))
      println(record)
    })*/
    val friends = args._2._1
    friends.foreach(value =>
    {
      record += ((value, loAge))
    })
    record.toArray
  }


  // Calculate average age of friends of each user
  def CalculateAveAgeReducer(args:(String, Iterable[Double])): (Double, String) = {
    var sumOfAges = 0.0
    var count = 0
    val values = args._2
    values.foreach(eachAge =>                 
    {
      sumOfAges += eachAge
      count += 1
    })

    if (count == 0)
    {
      return (0, args._1)
    }
    val averageAge = sumOfAges * 1.0 / count
    (averageAge, args._1)
  }


//Join Address
  def JoinAddressMapper(value:String, targetMap: Map[String, Double]): String = {

    val details = value.split(",")

    val currentUser = details(0)
    val address = details(3) + ", " + details(4) + ", " + details(5)

    val averageAge = "%.2f".format(targetMap.get(currentUser).get)

    currentUser + ", " + address + ", " + averageAge
  }

  def main(args: Array[String]) {
    val conf = new SparkConf().setAppName("Top friends by average age")
    conf.set("spark.hadoop.validateOutputSpecs", "false")
    val sc = new SparkContext(conf)
    if(args.length<2)
    {
      println("You should provide atlease 2 arguments")
      System.exit(-1)
    }
    else
    {
    val  inputPath = args(0)
    val inputPathForDetails = args(1)
    val  outputPath = args(2)
    val friendList = sc.textFile(inputPath)
    val friendDetails = sc.textFile(inputPathForDetails)

    val friendMapperResult = friendList.flatMap(JoinFriendMapper)
    val intermediateResult = friendDetails.map(JoinAgeMapper)
    val joinedFriendsAgeResult = friendMapperResult.cogroup(intermediateResult).flatMap(JoinFriendAgeReducer)

    val averageAgeResult = joinedFriendsAgeResult.groupByKey().map(CalculateAveAgeReducer)


    val sortedAverageAgeResult = averageAgeResult.sortByKey(false).map(tuple => (tuple._2, tuple._1))    // revert to (uid, ave age)


    val top20Result = sortedAverageAgeResult.take(20)
    var target = Map[String, Double]()
    top20Result.foreach(tuple => target += (tuple._1 -> tuple._2))
    val targetBroadCast = sc.broadcast(target)
    val addressMapperResult = friendDetails.filter(line => targetBroadCast.value.contains(line.split(",")(0))).
      map(line => JoinAddressMapper(line, targetBroadCast.value))


    val finalResult = addressMapperResult
    finalResult.saveAsTextFile(outputPath)
    }
  }
}